<?php
// Plugin Info
class MaliciousPlugin {
    public static function activate() {
        return true;
    }
}
?>
